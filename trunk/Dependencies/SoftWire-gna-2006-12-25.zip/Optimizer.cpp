#include "Optimizer.hpp"

namespace SoftWire
{
	Optimizer::Optimizer(bool x64) : RegisterAllocator(x64)
	{
	}

	Optimizer::~Optimizer()
	{
	}
}

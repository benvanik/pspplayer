#include "Optimizer.hpp"

namespace SoftWire
{
	Optimizer::Optimizer()
	{
	}

	Optimizer::~Optimizer()
	{
	}
}
